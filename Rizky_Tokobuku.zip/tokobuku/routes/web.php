<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

use Facade\FlareClient\View;
// use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return view('welcome');
});

// Route::get('/buku', function () {
//     return view('data_buku');
// });


Route::get('/buku','BukuController@index');
Route::get('/buku/cetak','BukuController@cetak');

Route::get('/buku/create','BukuController@create');
Route::post('/buku/add','BukuController@store');

Route::get('/edit/{id}', 'BukuController@edit');
Route::post('/edit/{id}', 'BukuController@update');

Route::get('{id}','BukuController@destroy');

Route::get('/buku/cetak_pdf','BukuController@cetak_pdf');

Route::get('/buku/cetak_xlsx','BukuController@cetak_xlsx');

Route::get('/buku/cetak_doc','BukuController@cetak_doc');
