<?php

namespace App\Http\Controllers;

use App\Buku;
use App\Exports\BukuExport;
use PDF;
use Illuminate\Http\Request;
use Maatwebsite\Excel\Facades\Excel;

class BukuController extends Controller
{
    // Controller Buku
    public function index()
    {
        $buku = Buku::all();

        return view('buku/data', compact(
            'buku'
        ));
    }

    public function create()
    {
        return view('buku/create');
    }

    public function store(Request $request)
    {
        $buku  = new Buku();
        $buku->judul = $request->get('judul');
        $buku->harga = $request->get('harga');
        $buku->save();
        return redirect('buku')->with('success', 'Data Masuk');
    }

    public function update(Request $request, $id)
    {
        $buku = Buku::find($id);
        $buku->judul = $request->get('judul');
        $buku->harga = $request->get('harga');
        $buku->save();
        return redirect('buku')->with('success', 'Data Update');
    }

    public function edit($id)
    {
        $buku = Buku::find($id);
        return view('buku/edit', compact('buku', 'id'));
    }

    public function destroy($id)
    {
        $buku = Buku::find($id);
        $buku->delete();
        return redirect('buku')->with('success', 'Data Terhapus');
    }

    public function cetak_pdf()
    {
        $buku = Buku::all();
        $date = date('Y-m-d H:i:s');

        $pdf = PDF::loadview('buku/buku_pdf', ['buku' => $buku]);
        return $pdf->download('laporan-buku-' . $date . '.pdf');
    }

    public function cetak_xlsx()
    {
        return Excel::download(new BukuExport, 'laporan.xlsx');
    }

    public function cetak_doc(){
        $buku = Buku::all();

        foreach ($buku as $item) :
            $judul[] = $item->judul;
            $harga[] = $item->harga;
        endforeach;

        $jml1 = count($judul);

        $phpWord = new \PhpOffice\PhpWord\PhpWord();

        $section = $phpWord->addSection();

        for($i=0;$i<$jml1;$i++) :
        $section->addText($judul[$i].' => '.$harga[$i]);
        endfor;

        $objWriter = \PhpOffice\PhpWord\IOFactory::createWriter($phpWord, 'Word2007');
        try {
            $objWriter->save(storage_path('LaporanBuku.docx'));
        } catch (Exception $e) {
        }


        return response()->download(storage_path('LaporanBuku.docx'));


    }


    // public function cetak(){
    //     $buku = Buku::all();

    //     $pdf = PDF::loadview('buku.data',['buku'=>$buku]);
    //     return $pdf->download('data-buku.pdf');
    // }


}
