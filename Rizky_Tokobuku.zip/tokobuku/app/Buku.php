<?php

namespace App;

// use Illuminate\Database\Eloquent\Model;
use Jenssegers\Mongodb\Eloquent\Model as Moloquent;

class Buku extends Moloquent
{
    //
    protected $connection = 'mongodb';
    protected $collection = 'buku';

    protected $fillable = [
        'judul', 'harga'
    ];

}
