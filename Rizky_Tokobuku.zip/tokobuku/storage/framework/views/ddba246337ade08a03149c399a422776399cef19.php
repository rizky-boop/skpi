<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Edit Buku</title>
</head>
<body>
<form action="<?php echo e(action('BukuController@update',$id)); ?> " method="post">
<?php echo csrf_field(); ?>
<div class="row">
    <div class="col">
        <label for="Judul">Judul</label>
        <input type="text" name="judul" id="Judul" value="<?php echo e($buku->judul); ?> ">
    </div>
</div>
<div class="row">
    <div class="col">
        <label for="Harga">Harga</label>
        <input type="text" name="harga" id="Harga" value="<?php echo e($buku->harga); ?> ">
    </div>
</div>
<div class="row">
    <div class="col">
        <div class="form-group">
            <button type="submit">Update</button>
        </div>
    </div>
</div>
</form>
</body>
</html>
<?php /**PATH C:\laragon\www\tokobuku\resources\views/buku/edit.blade.php ENDPATH**/ ?>