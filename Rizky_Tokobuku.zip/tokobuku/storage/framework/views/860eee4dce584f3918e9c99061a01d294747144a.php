<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Tambah Buku</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css"
    integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
</head>
<body>
<h1>Tambah Buku</h1>
<form action="<?php echo e(url('buku/add')); ?>" method="post">
<?php echo csrf_field(); ?>
<div class="row">
    <div class="col">
        <div class="form-group">
            <label for="Judul">Judul Buku</label>
            <input type="text" name="judul" id="Judul">
        </div>
    </div>
</div>
<div class="row">
    <div class="col">
        <div class="form-group">
            <label for="Harga">Harga</label>
            <input type="text" name="harga" id="Harga">
        </div>
    </div>
</div>
<div class="row">
    <div class="col">
        <button type="submit">Submit</button>
    </div>
</div>
</form>
</body>
</html>
<?php /**PATH C:\laragon\www\tokobuku\resources\views/buku/create.blade.php ENDPATH**/ ?>